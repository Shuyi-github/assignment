function [ f ] = predictive2( t,x)
f=(x')*t;
end 
